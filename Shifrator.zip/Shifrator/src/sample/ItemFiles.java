package sample;

public class ItemFiles {

    public int index;
    public String path;
    public String name;
    public String date;

    public ItemFiles(int index, String path, String name, String date) {
        this.index = index;
        this.path = path;
        this.name = name;
        this.date = date;
    }

    @Override
    public String toString() {
        return index+"\t|\t"+path+"\t|\t"+date;
    }
}
