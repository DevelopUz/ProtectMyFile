package sample;

import com.jfoenix.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.util.*;
import java.io.*;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Controller implements Initializable{

    private File dataBaseFolder; //Fayllar saqlanadigan joy
    private File propertiesFile; //Ma'lumotlar ombori

    private List<File> files; //Himoyalash uchun tanlangan fayllar
    private File folder; //Qayta tiklash uchun tanlangan Joy
    private FileChooser fileChooser;
    private DirectoryChooser folderChooser;
    private ArrayList<ItemFiles> itemFiles; //bazada bor bo'lgan fayllar
    private ObservableList<String> myList =  FXCollections.observableArrayList(); //bazada bor bo'lgan fayllar

    @FXML
    public JFXTextField FileChooserField;
    public JFXButton checkbutton;
    public JFXListView<String> listView;
    @FXML
    public TextField pointFrom;
    public TextField pointTo;
    public TextField RecoverPath;
    @FXML
    public JFXProgressBar progressBar;
    public JFXButton okButton;
    public StackPane stackPane;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        listView.setItems(myList);

        dataBaseFolder = new File("C:\\Hidden");
        propertiesFile = new File("C:\\windows.prop");

        progressBar.setVisible(false);
        fileChooser = new FileChooser();
        folderChooser = new DirectoryChooser();
        itemFiles = new ArrayList<>();
        try {
            gettingReady();
            showHiddenFiles();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void MasterEncryptionFunction() throws Exception {
        Thread t = new Thread(()->{
            progressBar.setVisible(true);
            FileWriter writer;
            try {
                writer = new FileWriter(propertiesFile, true);

                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd/HH:mm:ss");

                for (File file : files) {

                    EncryptionClass.EncodeFile(file, new File("C:\\Hidden\\" + file.getName()));

                    Date date = new Date();

                    writer.write(file.getPath() + "#" + dateFormat.format(date) + "\n\r");

                    if (file.delete()) {
                        System.out.println(file.getName() + " is deleted!");
                    } else {
                        System.out.println("Delete operation is failed.");
                    }
                }

                writer.flush();
                writer.close();

            } catch (IOException  e) {
                e.printStackTrace();
            }
            progressBar.setVisible(false);
        });
        if (!files.isEmpty()) {
            t.start();
        }
    }

    //---------------------------Decryption-----------------------------//

    private ArrayList<ItemFiles> setOfFiles(){

        ArrayList<ItemFiles> returnItem = new ArrayList<>();
        ArrayList<ItemFiles> qolganFayllar = new ArrayList<>();

        if (!pointFrom.getText().isEmpty()) {
            int begin = Integer.parseInt(pointFrom.getText());
            int end = begin;
            if (!pointTo.getText().isEmpty()) {
                end = Integer.parseInt(pointTo.getText());
            }
            File file = new File(RecoverPath.getText());
            for (int i = begin; i <= end; i++) {
                for (ItemFiles files : itemFiles) {
                    if (files.index == i) {
                        returnItem.add(files);
                    }else {
                        qolganFayllar.add(files);
                    }
                }
            }
        }

        itemFiles = qolganFayllar;

        return returnItem;
    }

    public void MasterDecryptionFunction() throws IOException {

        ArrayList<ItemFiles> DecodableFiles = setOfFiles();

        Thread t = new Thread(()->{
            progressBar.setVisible(true);
            for (ItemFiles files :DecodableFiles) {
                File recFile = new File(files.path);
                File targrtFile = new File("C:\\Hidden\\"+recFile.getName());
                try {
                    EncryptionClass.DecodeFile(targrtFile, recFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (targrtFile.delete()){
                    System.out.println("target File deleted");
                }
            }
            try {
                updateDataBase();
                showHiddenFiles();
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
            progressBar.setVisible(false);
        });
        if (!DecodableFiles.isEmpty()) {
            t.start();
        }
    }

    //-----------------------------Tayyor-------------------------------//

    //FXML
    public void FileChooser(MouseEvent mouseEvent) {
        files = fileChooser.showOpenMultipleDialog(new Stage());
        FileChooserField.setText(files.toString());
    }

    public void FolderChooser(MouseEvent mouseEvent) {
        folder = folderChooser.showDialog(new Stage());
        RecoverPath.setText(folder.getPath());
    }

    private void gettingReady() throws IOException, InterruptedException {
        if (!dataBaseFolder.exists()){
            System.out.println("no Folder I have create one.");
            dataBaseFolder.mkdir();
            createHidden(dataBaseFolder);
        }
        if (!propertiesFile.exists()){
            System.out.println("no File I have create one.");
            propertiesFile.createNewFile();
            createHidden(propertiesFile);
        }
    }

    private void createHidden(File file) throws IOException, InterruptedException {
        Process p = Runtime.getRuntime().exec("ATTRIB +H " + file.getPath());
        p.waitFor();
        p.exitValue();
    }

    //------------------------------Tools--------------------------------//

    private static void changeFileAttrib(File targetFile, String attrib) throws IOException, InterruptedException {
        Process p = Runtime.getRuntime().exec("ATTRIB "+attrib+" " + targetFile.getPath());
        p.waitFor();
        p.exitValue();
    }

    private void showHiddenFiles() throws IOException, InterruptedException {
        changeFileAttrib(propertiesFile, "-H");

        BufferedReader reader = new BufferedReader(new FileReader(propertiesFile));
        int index = 1;
        itemFiles.clear();
        myList.clear();
        while (reader.ready()){
            String readLine = reader.readLine();
            if (readLine.length() < 18) continue;
            StringTokenizer tokenizer = new StringTokenizer(readLine, "#");
            ItemFiles itemFiles1 = new ItemFiles(index, tokenizer.nextToken(), "", tokenizer.nextToken());
            itemFiles.add(itemFiles1);
            myList.add(itemFiles1.toString());
            index++;
        }
        reader.close();
        changeFileAttrib(propertiesFile, "+H");
    }

    private void updateDataBase() throws IOException, InterruptedException {
        changeFileAttrib(propertiesFile, "-H");

        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(propertiesFile, false));

        for (ItemFiles files : itemFiles) {
            bufferedWriter.write(files.path + "#" + files.date + "\n\r");
        }

        bufferedWriter.flush();
        bufferedWriter.close();

        changeFileAttrib(propertiesFile, "+H");
    }//data base ga yozib qo'yish

    @FXML
    private void okButton_Click(){
        stackPane.setVisible(false);
    }

    public void RegButton_Click(MouseEvent mouseEvent) throws IOException {

    }
}
