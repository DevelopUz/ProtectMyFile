package sample;

import java.io.*;

public class Authentication {

    public String login;
    public String password;


    public Authentication() {
    }

    public static boolean checkForRegistration() throws IOException {

        File file = new File("C:\\Windows\\system.aut");
        String login;
        String pass;
        if (file.exists()){
            BufferedReader reader = new BufferedReader(new FileReader(file));
            login = reader.readLine();
            pass = reader.readLine();
            if (login.isEmpty() && pass.isEmpty()){
                reader.close();
                return false;
            }else {
                reader.close();
                return true;
            }
        }
        return false;
    }

    public  static boolean registration(){
        return true;
    }

    public static boolean authenticate(String login, String kalit){
        return true;
    }



}
