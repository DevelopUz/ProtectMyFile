package sample;

import java.io.*;

public class EncryptionClass {

    public static void EncodeFile(File targetFile, File encodedFile) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(targetFile);
        FileOutputStream fileOutputStream = new FileOutputStream(encodedFile);

        int buffer;

        while ((buffer = fileInputStream.read()) != -1){
            fileOutputStream.write(buffer+1);
        }

        fileOutputStream.flush();
        fileOutputStream.close();
        fileInputStream.close();
    }

    public static void DecodeFile(File targetFile, File decodeedFile) throws IOException {
        FileInputStream stream1 = new FileInputStream(targetFile);
        FileOutputStream stream2 = new FileOutputStream(decodeedFile);

        int buffer;

        while ((buffer = stream1.read()) != -1){
            stream2.write(buffer-1);
        }

        stream2.flush();
        stream2.close();
        stream1.close();
    }

}
