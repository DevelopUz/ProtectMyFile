package SqLite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SqlConnection {

    public static Connection DbConnection(){
        try {
            Connection conn = null;
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:ShifratorDb.sqlite");
            return conn;
        }catch (Exception e){
            return null;
        }
    }

    public static void CheckConnection(){
        Connection conn = SqlConnection.DbConnection();
        if (conn == null){
            System.out.println("Connection Not Succesful");
            System.exit(1);
        }else {
            System.out.println("Connection Succesful");
        }
    }

    public static void tekshir(){
        String query = "select * from MyProtectedFiles";
        try {
            PreparedStatement statement = DbConnection().prepareStatement(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
